function getData(){
    function addData(chart, label, data) {
        chart.data.labels.push(label);
        chart.data.datasets.forEach((dataset) => {
            dataset.data.push(data);
        });
        chart.update();
    }

    option = {
        // The type of chart we want to create
        type: 'polarArea',
    
        // The data for our dataset
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [] ,
                label: 'My dataset' // for legend
            }],
        },
        options: {
            responsive: true,
            legend: {
                position: 'right',
            },
            title: {
                display: true,
                fontSize: 20,
                text: 'Nombre de perte d objet'
            },
            scale: {
                ticks: {
                    beginAtZero: true
                },
                reverse: false
            },
            animation: {
                animateRotate: true,
                animateScale: true
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById('chart-area');
        window.myPolarArea = Chart.PolarArea(ctz, config);
    };

    $.getJSON("./json/nbIncidentsParAn.json", function(data){
        console.log(data.length);
        data.forEach(function(element,index, array){
           addData(ctz,element._id,element.nbIncidents);     
        });
    });

}



// window.onload = function() {
//     var ctx = document.getElementById('chart-area');
//     window.myPolarArea = Chart.PolarArea(ctz, config);
// };

// var colorNames = Object.keys(window.chartColors);
// document.getElementById('addData').addEventListener('click', function() {
//     if (config.data.datasets.length > 0) {
//         config.data.labels.push('data #' + config.data.labels.length);
//         config.data.datasets.forEach(function(dataset) {
//             var colorName = colorNames[config.data.labels.length % colorNames.length];
//             dataset.backgroundColor.push(window.chartColors[colorName]);
//             dataset.data.push(randomScalingFactor());
//         });
//         window.myPolarArea.update();
//     }
// });

