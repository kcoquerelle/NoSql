var ctx = document.getElementById('myChart').getContext('2d');
new Chart(ctx, {
    // The type of chart we want to create
    type: 'bar',

    // The data for our dataset
    data: {
        responsive: false,
        labels: ["Paris Saint-Lazare", "Miramas", "Bordeaux", "Sibelin", "Hourcade", "Woippy", "Chambéry","Nimes","Paris Montparnasse","Rennes"],
        datasets: [{
            data: [
                32, 29, 24, 23, 17, 17, 16, 16, 13, 13
            ],
            backgroundColor: [
                'rgba(255, 99, 132,0.5)',
                'rgba(255, 0, 132,0.5)',
                'rgba(255, 99, 0,0.5)',
                'rgba(54, 153, 137, 0.5)',
                'rgba(183, 57, 137, 0.5)',
                'rgba(253, 244, 0, 0.5)',
                'rgba(253, 106, 0, 0.5)',
                'rgba(100,0,4,0.5)',
                'rgba(0,100,4,0.5)',
                'rgba(4,0,100,0.5)'
            ] ,
        }],
    },
    options: {
        responsive: false,
        legend: {
            position: 'right',
        },
        title: {
            display: true,
            fontSize: 20,
            text: 'Incidents Gares'
        },
        // scale: {
        //     ticks: {
        //         beginAtZero: true
        //     },
        //     reverse: false
        // },
        animation: {
            animateRotate: true,
            animateScale: true
        }
    }
});

var ctz = document.getElementById('ChartMax');
new Chart(ctz,{
    // The type of chart we want to create
    type: 'doughnut',

    // The data for our dataset
    data: {
        labels: ["Paris Rive-Gauche","Paris Est","Paris Austerlitz","Paris Batignolles","Paris Bercy","Paris la Vilette","Paris","Paris Le Landy","Paris Charolais","Paris Montparnasse","Paris Gare du Nord","Paris Gare de Lyon","Paris Ourcq","Paris Saint-Lazare","Paris Sud-Est"],
        datasets: [{
            data: [1,9,5,1,11,1,1,1,1,13,4,8,1,32,2],
            backgroundColor: [
                'rgba(255, 99, 132,0.5)',
                'rgba(255, 0, 132,0.5)',
                'rgba(255, 99, 0,0.5)',
                'rgba(54, 153, 137, 0.5)',
                'rgba(183, 57, 137, 0.5)',
                'rgba(253, 244, 0, 0.5)',
                'rgba(253, 106, 0, 0.5)',
                'rgba(100,0,4,0.5)',
                'rgba(0,100,4,0.5)',
                'rgba(4,0,100,0.5)',
                'rgba(59,20,56,0.5)',
                'rgba(73,35,118 ,0.5)',
                'rgba(57,78,254 ,0.5)',
                'rgba(205,1,249 ,0.5)',
                'rgba(48,161,94 ,0.5)'
            ] ,
            label: 'My dataset' // for legend
        }],
    },
    options: {
        responsive: false,
        legend: {
            position: 'right',
        },
        title: {
            display: true,
            fontSize: 20,
            text: 'Nombre a Paris'
        },
        // scale: {
        //     ticks: {
        //         beginAtZero: true
        //     },
        //     reverse: false
        // },
        animation: {
            animateRotate: true,
            animateScale: true
        }
    }
});
var ctr = document.getElementById('ChartLine').getContext('2d');
var chart = new Chart(ctr, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: ["2014", "2015", "2016", "2017"],
        datasets: [{
            label: "My First dataset",
            backgroundColor: 'rgba(255, 99, 132,0.5)',
            borderColor: 'rgb(255, 99, 132)',
            data: [439, 752, 660, 520],
        }]
    },

    // Configuration options go here
    options: {
        legend: {
            position: 'right',
        },
        title: {
            display: true,
            fontSize: 20,
            text: 'Nombre d\'incidents par annnées'
        }
    }
});


(function($) {
    "use strict"; // Start of use strict
  
    // Smooth scrolling using jQuery easing
    $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        if (target.length) {
          $('html, body').animate({
            scrollTop: (target.offset().top)
          }, 1000, "easeInOutExpo");
          return false;
        }
      }
    });
  
    // Closes responsive menu when a scroll trigger link is clicked
    $('.js-scroll-trigger').click(function() {
      $('.navbar-collapse').collapse('hide');
    });
  
    // Activate scrollspy to add active class to navbar items on scroll
    $('body').scrollspy({
      target: '#sideNav'
    });
  
  })(jQuery); // End of use strict
  